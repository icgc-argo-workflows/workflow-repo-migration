# GATK Base Quality Score Recalibration Workflow implemented in Nextflow

Note: GATK BQSR workflow reference implementation in WDL: https://github.com/gatk-workflows/gatk4-data-processing/blob/master/processing-for-variant-discovery-gatk4.wdl
