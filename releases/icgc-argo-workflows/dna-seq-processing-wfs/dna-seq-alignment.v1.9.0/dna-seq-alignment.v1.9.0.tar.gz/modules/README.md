Nextflow modules in this directory are managed programatically, they are mirrored from corresponding Github repo raw contents.
Please do not manually edit them.

To install remote Nextflow modules locally here, just run the following command:
```
../scripts/install-modules.py
```

You may include `-c` option to remove unused module files:
```
../scripts/install-modules.py -c
```
