# GATK Calculate Contamination Workflow implemented in Nextflow

 Note: this Nextflow implementaiton followed the GATK's WDL implementation: https://github.com/gatk-workflows/gatk4-somatic-snvs-indels/blob/master/mutect2.wdl
 