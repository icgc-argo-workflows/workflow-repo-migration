This folder contains tiny data files for testing.
