This folder contains tiny data files for testing from https://github.com/getzlab/deTiN/tree/master/example_data.
